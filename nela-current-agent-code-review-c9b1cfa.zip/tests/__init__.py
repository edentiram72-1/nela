"""Tests for NELA OS."""

