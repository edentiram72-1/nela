"""Desktop agent module."""

