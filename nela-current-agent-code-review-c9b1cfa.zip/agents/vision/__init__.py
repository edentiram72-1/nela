"""Vision agent module."""

