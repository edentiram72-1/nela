"""Spotify agent module."""

