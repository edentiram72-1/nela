"""Calendar agent module."""

