"""Sidebar component package."""

