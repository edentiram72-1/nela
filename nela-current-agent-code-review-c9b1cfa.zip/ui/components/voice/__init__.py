"""Voice component package."""

