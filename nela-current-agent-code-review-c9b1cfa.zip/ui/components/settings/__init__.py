"""Settings component package."""

