"""Chat component package."""

